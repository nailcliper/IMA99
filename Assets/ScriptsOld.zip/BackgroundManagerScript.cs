﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundManagerScript : MonoBehaviour {

    public GameObject background;
    public BackgroundTilingScript bgScript;

    public GameObject spellcard;
    public BackgroundTilingScript spScript;

    public GameObject blackground;
    public BackgroundTilingScript blScript;

    public GameObject foreground;

    void Awake()
    {
        background = gameObject.transform.Find("Background").gameObject;
        bgScript = background.GetComponent<BackgroundTilingScript>();
        bgScript.SetColor("clear");
        foreground = background;

        spellcard = gameObject.transform.Find("Spellcard").gameObject;
        spScript = spellcard.GetComponent<BackgroundTilingScript>();
        spScript.SetColor("clear");

        blackground = gameObject.transform.Find("Blackground").gameObject;
        blScript = spellcard.GetComponent<BackgroundTilingScript>();
        blScript.SetColor("black");
    }

    public void SetBackground(Material bg, Vector2 scrollSpeed)
    {
        Coroutine backRoutine = StartCoroutine(SetBack(bg, scrollSpeed));
    }

    IEnumerator SetBack(Material bg, Vector2 scrollSpeed)
    {
        bgScript.FadeClear(0.75f);
        yield return new WaitForSeconds(0.75f);
        bgScript.SetMaterial(bg);
        bgScript.scrollSpeed = scrollSpeed;
        bgScript.SetColor("clear");
        bgScript.FadeFull();
    }

    public void SetSpellcard(Material sp, Vector2 scrollSpeed)
    {
        bgScript.FadeClear(0.75f);
        spScript.SetMaterial(sp);
        spScript.scrollSpeed = scrollSpeed;
        spScript.SetColor("clear");
        spScript.FadeFull(0.75f);
        foreground = spellcard;
    }

    public void UnSetSpellcard()
    {
        bgScript.FadeFull(0.25f);
        spScript.FadeClear(0.25f);
        foreground = background;
    }
}
