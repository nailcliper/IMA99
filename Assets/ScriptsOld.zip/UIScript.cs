﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIScript : MonoBehaviour {

    public Text[] textObjs = new Text[6];

    public void SetString(string itext, int i)
    {
        textObjs[i].text = itext;
    }
}
