﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombItemScript : ItemScript {

    override public void Collect()
    {
        playerManager.GetComponent<PlayerManagerScript>().AddBomb();
        base.Collect();
    }
}
