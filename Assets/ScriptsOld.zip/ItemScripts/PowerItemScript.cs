﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerItemScript : ItemScript {
    public int powerValue = 1;

    public override void Collect()
    {
        playerManager.AddPower(powerValue);
        base.Collect();
    }
}
