﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarItemScript : ItemScript {

    void OnEnable()
    {
        AutoCollect();
    }

    void CalcStarPoint()
    {
        pointValue = (500 + (playerManager.GetGraze() / 3));
    }
}
