﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OneUpScript : ItemScript {

    override public void Collect()
    {
        playerManager.GetComponent<PlayerManagerScript>().AddLife();
        base.Collect();
    }
}
